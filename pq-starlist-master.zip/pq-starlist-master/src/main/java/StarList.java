import java.util.Iterator;

public class StarList /* implements TODO */ {

    private int size;
    private final int capacity;
    private Star[] starList;

    public StarList(int capacity) {
        this.size = 0;
        this.capacity = capacity;
        this.starList = new Star[capacity];
    }

    public void add(Star s) {
        if (size >= capacity) {
            throw new ArrayIndexOutOfBoundsException("List is full");
        }

        starList[size++] = s;
    }

    public Star get(int index) {
        return starList[index];
    }

    public boolean isEmpty() {
        return 0 == size;
    }

    public int size() {
        return size;
    }

    public int getCapacity() {
        return capacity;
    }

    @Override
    public String toString() {
        String str = "";
        for (int i = 0; i < size; ++i) {
            str += starList[i].toString();
            str += "\n";
        }
        return str;
    }

    public void sortByName() {
        // TODO: uncomment the line below once you've modified Star
        // to implement Comparable

        //SortWrapper.sort(starList);
    }

    /*** DO NOT MODIFY ANYTHING ABOVE THIS POINT ***
     *** ALL YOUR CHANGES SHOULD BE BELOW HERE   ***/

    public void sortByColor() {
        // TODO: uncomment and modify the line below adding the required
        // arguments to sort the array by Color using a lambda

        //SortWrapper.sort(         );
    }

    /* TODO: implement the required method of the Iterable<Star> interface */

    /* TODO: immplement an iterator called StarIterator */
}
