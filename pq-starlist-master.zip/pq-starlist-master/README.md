# pq-starlist
Sort using a lambda and create an iterator

Topics:
- lambdas
- iterators

Instructions are in `index.md`
